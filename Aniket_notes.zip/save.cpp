#include "save.h"

void save::set_monstercount(int count) { monsterCount = new int;
monsterCount[0] = count;}

int save::get_monstercount() { {return monsterCount[0];} }

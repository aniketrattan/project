#ifndef save_h
#define save_h

class save{
    protected:
    int* monsterCount;
    public:
    void set_monstercount(int count);
    int get_monstercount();
};

#endif
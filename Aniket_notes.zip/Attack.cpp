#include "Attack.h"

void Attack::attack(int damage, Attack &object ) {}
void Attack::set_health(int health) {}
int Attack::get_health() {}